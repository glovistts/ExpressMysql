module.exports = {
    HOST: "host.docker.internal",
    USER: "root",
    PASSWORD: "",
    DB: "expressjsauthdb"
  };